<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="shortcut icon" href="../view/img/image-removebg-preview.png" />
    <link rel="stylesheet" href="./css/headerAdmin.css">
    <link rel="stylesheet" href="./css/base.css">
    <link rel="stylesheet" href="./css/table.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Chakra+Petch&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- <script src="https://cdn.tailwindcss.com"></script> -->
</head>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<body>
    <?php
        include '../model/connect.php';
        connect_db();
        include '../model/category.php';
        include '../model/produce.php';
        include "../model/posts.php";
        include "../model/cart.php";
        if(isset($_GET['act']) && $_GET['act']){
            include "./view/adminHeader.php";
        }else{
            include "./view/dashboard.php";
        }
        include "../controller/controlAdmin.php";
    ?>
</body>

</html>