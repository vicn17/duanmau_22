<div class="menu_header">
    <div class="menu_header_center">
        <h1>Vicn</h1>
        <input type="checkbox" name="" id="click_menu_btn" />
        <nav>
            <ul>
                <li>
                    <a href="./index.php">Trang chủ</a>
                </li>
                <li>
                    <a href="<?= $_SERVER['PHP_SELF'] ?>?page=news">Tin tức</a>
                </li>
                <li>
                    <a href="./view/order.php">Sản phẩm</a>
                </li>
                <li>
                    <a href="#last_section">Cửa hàng</a>
                </li>
                <li>
                    <a href="<?= $_SERVER['PHP_SELF'] ?>?page=recruit">Tuyển dụng</a>
                </li>
                <li>
                    <a href="">Nhượng quyền</a>
                </li>
            </ul>
        </nav>
        <label class="menu_btn" for="click_menu_btn"><i class="fa-solid fa-bars"></i></label>
    </div>
</div>
<div class="text-banner">
    <div class="">
        <h3>VICN Tea</h3>
        <h1>
            đậm vị thiên nhiên <br />
            trọn vị hạnh phúc
        </h1>
        <p>
            Với sứ mệnh mang tới niềm vui và hạnh phúc, VICN hy vọng sẽ tạo
            nên
            <br />
            một nét văn hóa giải trí bên cạnh ly trà sữa Ngon – sạch – tươi.
        </p>
        <a class="btn-login" href="<?= $_SERVER['PHP_SELF'].'?page=login' ?>"> Đăng nhập </a>
    </div>
</div>